import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as sqs from 'aws-cdk-lib/aws-sqs';

interface KitStackProps extends cdk.StackProps {
  // params: object;
  params: {
    fifo: string,
    account: string,
    region: string
  };
}

export class QueueStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: KitStackProps) {
    super(scope, id, props);

    let fifoFlag = false;
    if (props.params.fifo === "true") {
      fifoFlag = true;
    }
    const queue = new sqs.Queue(this, 'SqsQueue', {
      fifo: fifoFlag,
      visibilityTimeout: cdk.Duration.seconds(300)
    });

  }
}
