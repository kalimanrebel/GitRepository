// const cdk = require('aws-cdk-lib');
// const { Template } = require('aws-cdk-lib/assertions');
// const JsKit = require('../lib/js-kit-stack');

// example test. To run these tests, uncomment this file along with the
// example resource in lib/js-kit-stack.js
test('SQS Queue Created', () => {
//   const app = new cdk.App();
//   // WHEN
//   const stack = new JsKit.JsKitStack(app, 'MyTestStack');
//   // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
});
